/** Automatically generated file. DO NOT MODIFY */
package ssg.chat;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}